self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e4bb06b3bea88cb67bab91e5e249c6e5",
    "url": "/index.html"
  },
  {
    "revision": "6519000d812bf68179ce",
    "url": "/static/css/main.6597e460.chunk.css"
  },
  {
    "revision": "c3d93c9d229a3bbf3092",
    "url": "/static/js/2.de6c3f8b.chunk.js"
  },
  {
    "revision": "5a1768750c09c8fadbc94e74a41bcc3a",
    "url": "/static/js/2.de6c3f8b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6519000d812bf68179ce",
    "url": "/static/js/main.8f83908b.chunk.js"
  },
  {
    "revision": "def558a0cc4c36d2aeae",
    "url": "/static/js/runtime-main.94253af3.js"
  },
  {
    "revision": "3f8024621c338f4bb1784c4a3c9940a5",
    "url": "/static/media/Cookie-Regular.3f802462.woff2"
  },
  {
    "revision": "08de7edb738c5885f66660af7756cc12",
    "url": "/static/media/bmc-new-btn-logo.08de7edb.svg"
  },
  {
    "revision": "6483c3dfdda3dc8f9ded3aeb3a0876de",
    "url": "/static/media/btcdonation.6483c3df.jpeg"
  }
]);